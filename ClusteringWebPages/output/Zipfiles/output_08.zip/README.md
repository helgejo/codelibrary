The files with the clusterings for the test data must be placed here.
Specifically, there should be the following 30 files:

```
Alvin_Cooper.clust.xml
Arthur_Morgan.clust.xml
Chris_Brockett.clust.xml
Dekang_Lin.clust.xml
Frank_Keller.clust.xml
George_Foster.clust.xml
Harry_Hughes.clust.xml
James_Curran.clust.xml
James_Davidson.clust.xml
James_Hamilton.clust.xml
James_Morehead.clust.xml
Jerry_Hobbs.clust.xml
John_Nelson.clust.xml
Jonathan_Brooks.clust.xml
Jude_Brown.clust.xml
Karen_Peterson.clust.xml
Leon_Barrett.clust.xml
Marcy_Jackson.clust.xml
Mark_Johnson.clust.xml
Martha_Edwards.clust.xml
Neil_Clark.clust.xml
Patrick_Killen.clust.xml
Robert_Moore.clust.xml
Sharon_Goldwater.clust.xml
Stephan_Johnson.clust.xml
Stephen_Clark.clust.xml
Thomas_Fraser.clust.xml
Thomas_Kirk.clust.xml
Violet_Howard.clust.xml
William_Dickson.clust.xml
```
